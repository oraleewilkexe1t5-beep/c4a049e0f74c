# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(bisect-regression src/bisect-regression.cpp)
set_property(TARGET bisect-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(bisect-regression lionss pthread)

add_executable(undefined-sanitizer src/undefined-sanitizer.cpp)
set_property(TARGET undefined-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(undefined-sanitizer lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(windows-x64 src/windows-x64.cpp)
set_property(TARGET windows-x64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x64 lionss pthread)

add_executable(thread-sanitizer src/thread-sanitizer.cpp)
set_property(TARGET thread-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-sanitizer lionss pthread)

add_executable(idempotency-tests src/idempotency-tests.cpp)
set_property(TARGET idempotency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(idempotency-tests lionss pthread)

add_executable(multilib-build src/multilib-build.cpp)
set_property(TARGET multilib-build PROPERTY CXX_STANDARD 11)
target_link_libraries(multilib-build lionss pthread)

add_executable(sast-scan src/sast-scan.cpp)
set_property(TARGET sast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(sast-scan lionss pthread)

add_executable(emscripten src/emscripten.cpp)
set_property(TARGET emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(emscripten lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(tidy-modernize src/tidy-modernize.cpp)
set_property(TARGET tidy-modernize PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-modernize lionss pthread)

add_executable(docs-examples src/docs-examples.cpp)
set_property(TARGET docs-examples PROPERTY CXX_STANDARD 11)
target_link_libraries(docs-examples lionss pthread)

add_executable(decoder-fuzz src/decoder-fuzz.cpp)
set_property(TARGET decoder-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(decoder-fuzz lionss pthread)

add_executable(aur-package src/aur-package.cpp)
set_property(TARGET aur-package PROPERTY CXX_STANDARD 11)
target_link_libraries(aur-package lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(pitest-run src/pitest-run.cpp)
set_property(TARGET pitest-run PROPERTY CXX_STANDARD 11)
target_link_libraries(pitest-run lionss pthread)

add_executable(codechecker src/codechecker.cpp)
set_property(TARGET codechecker PROPERTY CXX_STANDARD 11)
target_link_libraries(codechecker lionss pthread)

add_executable(offline-tests src/offline-tests.cpp)
set_property(TARGET offline-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(offline-tests lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(encoding-tests src/encoding-tests.cpp)
set_property(TARGET encoding-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(encoding-tests lionss pthread)

add_executable(linux-ppc64le src/linux-ppc64le.cpp)
set_property(TARGET linux-ppc64le PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-ppc64le lionss pthread)

add_executable(qemu-aarch64 src/qemu-aarch64.cpp)
set_property(TARGET qemu-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(qemu-aarch64 lionss pthread)

add_executable(changelog-render src/changelog-render.cpp)
set_property(TARGET changelog-render PROPERTY CXX_STANDARD 11)
target_link_libraries(changelog-render lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(build-debug src/build-debug.cpp)
set_property(TARGET build-debug PROPERTY CXX_STANDARD 11)
target_link_libraries(build-debug lionss pthread)

