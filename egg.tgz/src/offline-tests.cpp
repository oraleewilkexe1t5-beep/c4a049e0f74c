// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("offline tests\n", stdout);
  return lionss_run_workload("offline-tests");
}
