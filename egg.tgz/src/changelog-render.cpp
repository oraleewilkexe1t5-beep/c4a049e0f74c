// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("changelog render\n", stdout);
  return lionss_run_workload("changelog-render");
}
