// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("qemu aarch64"); }
int main(){
  announce();
  return lionss_run_workload("qemu-aarch64");
}
