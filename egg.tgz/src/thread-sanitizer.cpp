// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("thread sanitizer"); }
int main(){
  announce();
  return lionss_run_workload("thread-sanitizer");
}
